#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#define sleep(p)
int NUM_OF_CSV = 5;
int soldiers = 0;
int mineral_blocks = 2;
pthread_mutex_t soldiers_t;
pthread_mutex_t print_mutex;

struct MineralBlock{
    int minerals;
    pthread_mutex_t Block_mutex;
};

struct MineralBlock* Block;

struct CommandCenter{
    int minerals;
    pthread_mutex_t Center_mutex;
} Center;

void* CSV(void* attr){
    int number_of_CSV = (int*)attr;
    int not_empty_blocks[mineral_blocks];
    int not_empty_block = 0;
    for(int z=0 ;z < mineral_blocks; z++){
        not_empty_blocks[z] = 1;
    }
    int csv_minerals = 0;

    while(1){
        sleep(3);
        int help = -1;
        for(int i = 0;i < mineral_blocks;i++){
            if( not_empty_blocks[i] == 1){
                help = i;
                break;
            }
        }
        if(help == -1){
                return NULL;
        }
        if(not_empty_blocks[not_empty_block] == 0){
            not_empty_block++;
            not_empty_block %= mineral_blocks;
            continue;
        }
        if(pthread_mutex_trylock(&Block[not_empty_block].Block_mutex) == 0){
            if(Block[not_empty_block].minerals == 0){
                not_empty_blocks[not_empty_block] = 0;
                pthread_mutex_unlock(&Block[not_empty_block].Block_mutex);
                not_empty_block++;
                not_empty_block %= mineral_blocks;
                continue;
            }
            pthread_mutex_lock(&print_mutex);
            printf("SCV %d is mining from mineral block %d\n",number_of_CSV,not_empty_block+1);
            pthread_mutex_unlock(&print_mutex);
            if(Block[not_empty_block].minerals < 8){
                csv_minerals = Block[not_empty_block].minerals;
                Block[not_empty_block].minerals = 0;
                not_empty_blocks[not_empty_block] = 0; 
            }else{
                Block[not_empty_block].minerals -= 8;
                csv_minerals += 8;            
            }
            pthread_mutex_unlock(&Block[not_empty_block].Block_mutex);
            pthread_mutex_lock(&print_mutex);
            printf("SCV %d is transporting minerals\n",number_of_CSV);
            pthread_mutex_unlock(&print_mutex);
            sleep(2);
            pthread_mutex_lock(&Center.Center_mutex);
            pthread_mutex_lock(&print_mutex);
            printf("SCV %d delivered minerals to the Command center\n",number_of_CSV);
            pthread_mutex_unlock(&print_mutex);
            Center.minerals += csv_minerals;
            csv_minerals = 0; 
            //printf("center minerals: %d block minerals %d\n",Center.minerals,Block[not_empty_block].minerals);
            pthread_mutex_unlock(&Center.Center_mutex);
        }
        not_empty_block++;
        not_empty_block %= mineral_blocks;
    }
    return NULL;
}

void setup(int argc, char **argv){
    Center.minerals = 0;
    if(argc>1){
        mineral_blocks = atoi(argv[1]);
    }
    Block = malloc(mineral_blocks * sizeof(struct MineralBlock));
    for(int i=0;i<mineral_blocks;i++){
        Block[i].minerals = 500;
    } 
}

int main(int argc, char **argv)
{
    setup(argc,argv);
    char ch = 0;
    pthread_t CSVs[100];
    pthread_t Soldiers;
    int i = 0;
    for(i = 0; i < mineral_blocks; i++)
    {
        pthread_mutex_init(&Block[i].Block_mutex,NULL);
    }
    pthread_mutex_init(&Center.Center_mutex,NULL);
    pthread_mutex_init(&soldiers_t,NULL);
    pthread_mutex_init(&print_mutex,NULL);

    for (i = 0; i < NUM_OF_CSV; ++i)
    {    
        if(pthread_create(&CSVs[i],NULL,CSV,i + 1)){
            perror("pthread_create error\n");
            free(Block);
            return;
        }
    }

    while(1){
        pthread_mutex_lock(&soldiers_t);
        if(soldiers == 20){
            for (i = 0; i < NUM_OF_CSV; ++i)
            {
                if(pthread_join(CSVs[i], NULL)){
                    perror("pthread_join error\n");
                    free(Block);
                    return;
                }
            }
            free(Block);
            pthread_mutex_lock(&print_mutex);
            printf("Map minerals %d, player minerals %d, SCVs %d, Marines %d\n",mineral_blocks * 500,Center.minerals,NUM_OF_CSV,soldiers);
            pthread_mutex_unlock(&print_mutex);
            break;
        }
        pthread_mutex_unlock(&soldiers_t);
        ch = getchar();
        if(ch == 'm'){
            pthread_mutex_lock(&soldiers_t);
            pthread_mutex_lock(&Center.Center_mutex);
            if(Center.minerals >= 50){
                soldiers+=1;
                Center.minerals-=50;
                sleep(1);  
                pthread_mutex_lock(&print_mutex);
                printf("You wanna piece of me, boy?\n");
                pthread_mutex_unlock(&print_mutex);             
            }else{
                pthread_mutex_lock(&print_mutex);
                printf("Not enough minerals.\n");
                pthread_mutex_unlock(&print_mutex);        
            }
            pthread_mutex_unlock(&Center.Center_mutex);
            pthread_mutex_unlock(&soldiers_t);
        }else if(ch == 's'){
            pthread_mutex_lock(&soldiers_t);
            pthread_mutex_lock(&Center.Center_mutex);
            if(Center.minerals >= 50){
                Center.minerals -= 50;
                //printf("wait 4 sec?\n");
                sleep(4); 
                pthread_mutex_lock(&print_mutex);
                printf("SCV good to go, sir.\n");
                pthread_mutex_unlock(&print_mutex);                      
                i++;
                NUM_OF_CSV++;
                pthread_create(&CSVs[NUM_OF_CSV],NULL,CSV,i);
            }else{
                pthread_mutex_lock(&print_mutex);
                printf("Not enough minerals.\n");
                pthread_mutex_unlock(&print_mutex);
            }
            pthread_mutex_unlock(&Center.Center_mutex);
            pthread_mutex_unlock(&soldiers_t);
        }else{
            printf("Unsuported command ->\"%c\"\n",ch);
        }
    }

    // pthread_mutex_destroy(&mutex);
    // pthread_mutex_destroy(&command_center);
    return 0;
}
    //sudo apt install glibc-doc}